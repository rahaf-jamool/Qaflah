import axios from 'axios';

let apiToken = '';
export default  {
  BaseUrl : 'http://api.kmqlegal.net/',
  ApiToken : ''
}

