/**
 *  v-video-embed
 */

import Vue from 'vue'
import Embed from 'v-video-embed'

 Vue.use(Embed)