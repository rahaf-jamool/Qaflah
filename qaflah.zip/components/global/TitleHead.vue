<template>
  <div class="text-arrival" >
    <div class="title-arrival">
      <h2>{{title}}</h2>
    </div>
  </div>
</template>

<script>
export default {
  name: "Title Head",
  props: ['title'],
};
</script>
