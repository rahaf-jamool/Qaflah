<template>
  <div class="footer">
    <div class="details">
      <div class="left">
        <img src="../../assets/imgs/img_11.png" />
        <p>
          +971 888 777 666<br />
          +971 888 777 555<br />
          info@Qaflah-Logistics.com<br />
          UAE,Dubai,123st.
        </p>
        <ul class="social">
          <li><img src="../../assets/imgs/25.png" alt="" /></li>
          <li><img src="../../assets/imgs/26.png" alt="" /></li>
          <li><img src="../../assets/imgs/27.png" alt="" /></li>
          <li><img src="../../assets/imgs/28.png" alt="" /></li>
          <li><img src="../../assets/imgs/29.png" alt="" /></li>
          <li><img src="../../assets/imgs/30.png" alt="" /></li>
          <li><img src="../../assets/imgs/31.png" alt="" /></li>
        </ul>
      </div>
      <div class="right">
        <p>Home</p>
        <p>About Us</p>
        <p>Orders</p>
        <p>Media Center</p>
        <p>Companies</p>
        <p>Services</p>
        <p>Partners</p>
        <p><nuxt-link to="/terms-service">Terms of Service </nuxt-link></p>
      </div>
      <div class="right">
        <p>Home</p>
        <p>About Us</p>
        <p>Orders</p>
        <p>Media Center</p>
        <p>Companies</p>
        <p>Services</p>
        <p>Partners</p>
      </div>
    </div>
  </div>
</template>

<script>
import "../../public/assets/css/Footer.css";
export default {
  name: "Footer",
};
</script>
