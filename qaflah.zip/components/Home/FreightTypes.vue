<template>
  <div class="sectionTwo">
    <div class="freightContainer">
      <div class="text">
        <p>
          Lorem ipsum dolor sit ametperiam dolore consectetur adipisicing elit
          perferendis doloremque in molestiae fuga esse sed fugit voluptatibus
          fugiat rerum aperiam dolore Aut odio sunt ut tempora.
        </p>
      </div>
      <div class="freight">
        <div class="sea">
          <img src="~assets/imgs/05.png" alt="photo" />
          <p class="number">1400</p>
          <p class="text">Sea Freight</p>
        </div>
        <div class="land">
          <img src="~assets/imgs/04.png" alt="photo" />
          <p class="number">3200</p>
          <p class="text">Sea Freight</p>
        </div>
        <div class="air">
          <img src="~assets/imgs/03.png" alt="photo" />
          <p class="number">1200</p>
          <p class="text">Sea Freight</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import "../../public/assets/css/FreightTypes.css";
export default {
  name: "SectionTwo",
};
</script>

<style scoped></style>
