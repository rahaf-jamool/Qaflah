<template>
  <div class="briefpage">
    <div class="briefContainer">
      <img class="image" src="~assets/imgs/06.png" alt="" />
      <div class="imgs">
        <img class="img img1" src="~assets/imgs/07.png" alt="" />
        <img class="img" src="~assets/imgs/08.png" alt="" />
        <img class="img" src="~assets/imgs/09.png" alt="" />
      </div>
      <div class="detailsContainer">
        <div class="details">
          <div class="info">
            <div class="title">
              <p>Lorem ipsum dolor sit amet</p>
            </div>
            <div class="desc">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat,
                nam quasi expedita aspernatur corrupti dolore, repellendus
                nesciunt ratione incidunt quis iure illum odio necessitatibus
                explicabo doloribus eligendi facere placeat quod.
              </p>
            </div>
          </div>
        </div>
        <div class="details">
          <div class="info">
            <div class="title">
              <p>Lorem ipsum dolor sit amet</p>
            </div>
            <div class="desc">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat,
                nam quasi expedita aspernatur corrupti dolore, repellendus
                nesciunt ratione incidunt quis iure illum odio necessitatibus
                explicabo doloribus eligendi facere placeat quod.
              </p>
            </div>
          </div>
        </div>
        <div class="details">
          <div class="info">
            <div class="title">
              <p>Lorem ipsum dolor sit amet</p>
            </div>
            <div class="desc">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat,
                nam quasi expedita aspernatur corrupti dolore, repellendus
                nesciunt ratione incidunt quis iure illum odio necessitatibus
                explicabo doloribus eligendi facere placeat quod.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "../../public/assets/css/BriefPage.css";
export default {
  name: "briefpage",
};
</script>

<style scoped></style>
