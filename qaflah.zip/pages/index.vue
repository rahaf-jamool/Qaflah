<script>
import Home from "../components/Home/Home";
export default {
  layout: "app",
  name: "index",
  components: {
    Home,
  },
};
</script>
<template>
  <div>
    <Home />
  </div>
</template>

<style scoped></style>
