<script>
import visionMission from "../components/About/Vision.vue";
export default {
  layout: "app",
  name: "index",
  components: {
    visionMission,
  },
};
</script>
<template>
  <div style="padding-top: 100px;">
    <visionMission />
  </div>
</template>

<style scoped></style>
