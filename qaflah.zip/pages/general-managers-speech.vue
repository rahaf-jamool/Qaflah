<script>
import ManagersSpeech from "../components/About/Word.vue";
export default {
  layout: "app",
  name: "index",
  components: {
    ManagersSpeech,
  },
};
</script>
<template>
  <div style="padding-top: 100px;">
    <ManagersSpeech />
  </div>
</template>

<style scoped></style>
