<template>
<div style="padding-top: 100px">
  <Gallery/>
</div>
</template>

<script>
import Gallery from '~/components/Media/Gallery/Gallery.vue';

export default {
  components: {
    Gallery
  },
};
</script>
