<script>
import Video from "~/components/Media/Video/Video";

export default {
  layout: "app",
  name: "video",
  components: {
    Video,
  },
};
</script>
<template>
  <div style="padding-top: 100px">
    <Video />
  </div>
</template>
